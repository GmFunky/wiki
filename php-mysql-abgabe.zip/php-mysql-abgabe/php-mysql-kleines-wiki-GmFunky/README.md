# PHP-MySQL - Wiki

## Schritt 1: Datenbankstruktur überlegen für neue Aufgabe
Aufgabe Wiki: Gemacht wird ein kleines Wiki für ein Thema eurer Wahl (z.B. Tiere, Autos, Pflanzen, ...)
Ihr könnt dort Einträge anlegen, editieren und löschen. Die Einträge werden in der Datenbank gespeichert.
Vergesst nicht, dass ihr eine Tabelle braucht für den Login
