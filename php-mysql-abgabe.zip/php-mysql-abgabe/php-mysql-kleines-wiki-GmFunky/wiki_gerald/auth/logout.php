<?php 
/**
 * * Abmeldevorgang 
 * 
 */

 session_start();
 // Destoying All Sessions
 if(session_destroy())
{
      // Redirecting To Home Page
      hesder("Location: login.php");
}
?>
