<?php session_start();

require_once('../inc/login.inc.php');?>

<?php

/**
 *  Anmeldevorgang
 */
 

 if(isset($_GET['login'])) {
       $username = trim(htmlspecilchars($_POST['username']));
       $password = trim(htmlspecilchars($_POST['password']));


//Benutzereingaben Validieren 
       if(!empty($username) && !empty($password)) {
             $query = $con->prepare('SELECT username FROM useres WHERE username = ?
             AND password = ?');

             $password = md5($password);
             $query->bind_param('ss',$username,$password);
             $query->execute();
             $query->store_result();
             $query->bind_result($username);
             if($query->num_rows !=1){
                   $error ='Ihre Anmeldedaten sind nicht korrekt. Bitte wiederholen Sie Ihre Eingabe.';
             }  else {
                 var_dump($username);
                 $_SESSION['username']= $username;
                 // Redirect user to Index.php
                 header("Location: secret.php");
            }
      } else {
            $error = 'Bitte f&uuml;llen Sie alle Felder korrekt aus.';
      }
      
 } else {
       $error =NULL;
       $email =NULL;

 }
 ?>