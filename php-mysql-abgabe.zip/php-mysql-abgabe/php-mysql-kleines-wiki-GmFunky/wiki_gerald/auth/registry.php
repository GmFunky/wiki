<!doctype html>
<html>

<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Wiki Gerald</title>
      <link href="https://fonts.googleapis.com/css2?family=Gochi+Hand&family=Shrikhand&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
            integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" href="css/wiki.css">
</head>

<body>


      <?php

session_start();
require_once('../inc/login.inc.php');
?>

<?php

//Variable ob das Registrieungsformular angezeigt werden soll
$showFormular = true;

if(!isset($_GET['register'])){
      $error = false;
      $email = trim(htmlspecialchars($_REQUEST['email']));
      $password = trim(htmlspecialchars($_REQUEST['password']));
      $password2 = trim(htmlspecialchars($_REQUEST['password2']));
      $familyname = trim(htmlspecialchars($_REQUEST['familyname']));
      $forname = trim(htmlspecialchars($_REQUEST['forename']));
      $username = trim(htmlspecialchars($_REQUEST['username']));

      if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
            echo 'Bitte eine gültige email-Adresse eingeben</br>';
            $error =true;
      }
      if(strlen($password)==0) {
             echo 'Bitte ein Passwort eingeben</br>';

      if($password != $password2) {
            echo 'Die Passwörter müssen übereinstimmen</br>';
            $error = true;

      }

      // Überprüfe dass die email-adresse noch nicht registriert wurde
      if(!$error) {
            $resultc=$con->query("SELECT * FROM users WHERE email='" . $email ."'");

            // $result->execute();


      if($result->num_rows) {
            echo 'p class="bg-danger text-whitevm-5 p-5 text-center">Diese E-Mail-Adresse ist bereits vergeben</p>';
            $error = true;
         }
      }

   // Keine Fehler wir können den nutzer registrieren

   if(!$error) {
         var_dump($_REQUEST);
         $result = $con->query("INSERT INTO users (email,username, password,
         forename,familyname) VALUES ('$email','$username','".md5($password)."','$forname','$familyname')");
         var_dump($result);
         if($result){
               echo 'Du wurdest erfolgreich registriert.<a href="login.php">Zum Login</a>';
               $showFormular=false;
         } else {
               echo '<p class="bg-danger m-5 text-center">Beim Abspeichern ist leider ein Fehler aufgetreten</p>';
            }
      }
}
if(!$showFormular) {
      ?>

      <section class="h-100 mt-5 pt-5">
            <div class="container">
                  <form action="?register=1" method="post">
                        <div class="form-group">
                              <label for="forename">username</label>
                              <input type="text" size="40" maxlenght="250" name="username" id="forename" require>
                        </div>
                        <div class="form-group">
                              <label for="forname">Vorname</label>
                              <input type="text" size="40" maxlenght="250" name="famailyname" id="familyname" require>
                        </div>
                        <div class="form-group">
                              <label for="email">eMail Adresse</label>
                              <input type="email" size="40" maxlenght="250" name="email" id="email" require>
                        </div>
                        <div class="form-group">
                              <label for="password">Dein passwort:</label>
                              <input type="password" size="40" maxlenght="250" name="password" id="password" require>
                        </div>
                        <div class="form-group">
                              <label for="password2">passwort wiederholen:</label>
                              <input type="password2" size="40" maxlenght="250" name="password" id="password2" require>
                        </div>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                  </form>
            </div>
      </section>

      <?php
} // Ende vom if ($showformular)
?>

</body>

</html>